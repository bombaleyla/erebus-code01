from controller import Robot, Camera 
import numpy as np
import cv2


timestep = int(robot.getBasicTimeStep())


robot = Robot()



# Define the wheels 
wheel1 = robot.getDevice("wheel1 motor")    
wheel2 = robot.getDevice("wheel2 motor") 

wheel1.setPosition(float("inf"))       
wheel2.setPosition(float("inf"))

# Define distance sensors
s1 = robot.getDevice("distsens1")
s2 = robot.getDevice("distsens2")
s3 = robot.getDevice("distsens4")
s4 = robot.getDevice("distsens3")


s1.enable(timeStep)
s2.enable(timeStep)
s3.enable(timeStep)
s4.enable(timeStep)


camera = robot.getDevice("camera1")
camera.enable(timeStep)



start = robot.getTime()

cv2.namedWindow('frame2', cv2.WINDOW_NORMAL)
a = [[0] * 200 for i in range(200)]
mapping_img = np.zeros_like(a)
mapping_img = np.uint8(mapping_img)
for i in range(20):
    cv2.line(mapping_img, (i*10, 0), (i*10, 200), (146, 154, 161), 1)
    cv2.line(mapping_img, (0, i*10), (200, i*10), (146, 154, 161), 1)

lst = []
    
while robot.step(timeStep) != -1:
    #print("s1: " + str(s1.getValue()) + " s2: " + str(s2.getValue()) + " s3: " + str(s3.getValue()) + " s3: " + str(s4.getValue())
    print('-----------------')

    
    image = camera.getImage()

    width = camera.getWidth()
    height = camera.getHeight()
    image = np.frombuffer(image, dtype=np.uint8).reshape((height, width, 4))

    image = image[:, :, :3]
    
    gray_image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    

    cv2.imshow('Original Image', image)

    cv2.imshow("Original Image", mapping_img)
    cv2.waitKey(1)

    speed1 = 0
    speed2 = 0




