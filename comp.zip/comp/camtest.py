from controller import Robot, Camera
import cv2
import numpy as np

# Инициализация робота
robot = Robot()

# Получение временного шага симуляции
timestep = int(robot.getBasicTimeStep())

# Получение камеры робота
camera = robot.getDevice('camera1')
camera.enable(timestep)  # Включение камеры с заданным временным шагом

# Основной цикл симуляции
while robot.step(timestep) != -1:
    # Получение изображения с камеры
    image = camera.getImage()
    
    # Преобразование изображения в формат, понятный OpenCV
    # Изображение в Webots представлено как массив байтов (RGB)
    width = camera.getWidth()
    height = camera.getHeight()
    image = np.frombuffer(image, dtype=np.uint8).reshape((height, width, 4))
    
    # Убираем альфа-канал (если он есть)
    image = image[:, :, :3]
    
    # Преобразование изображения в оттенки серого (пример обработки)
    gray_image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    
    # Применение размытия (пример обработки)
    blurred_image = cv2.GaussianBlur(gray_image, (5, 5), 0)
    
    # Отображение изображений
    cv2.imshow('Original Image', image)
    cv2.imshow('Gray Image', gray_image)
    cv2.imshow('Blurred Image', blurred_image)
    
    # Ожидание нажатия клавиши (для корректного отображения окон)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Закрытие окон OpenCV
cv2.destroyAllWindows()
