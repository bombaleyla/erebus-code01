import cv2
import mediapipe as mp

# Инициализация mediapipe для обнаружения тела
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)
mp_drawing = mp.solutions.drawing_utils

# Открываем камеру
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Преобразуем кадр в RGB
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Обрабатываем кадр и получаем результат
    result = pose.process(frame_rgb)

    # Отображаем ключевые точки тела
    if result.pose_landmarks:
        mp_drawing.draw_landmarks(frame, result.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # Показываем кадр с ключевыми точками
    cv2.imshow("Body Tracking", frame)

    # Прерывание по нажатию клавиши 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Закрытие камеры и окон
cap.release()
cv2.destroyAllWindows()
