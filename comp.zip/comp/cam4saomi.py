import cv2
import time
cap = cv2.VideoCapture('http://10.2.0.157:4747/video?320x240')
#cap.set(3,320)    
#cap.set(4,240)

def nothing(*args):
    pass

cv2.namedWindow('settings', cv2.WINDOW_GUI_NORMAL)
cv2.namedWindow('frame', cv2.WINDOW_NORMAL)
cv2.createTrackbar('AREA_TRESH', 'settings', 0,255, nothing)
cv2.createTrackbar('AREA_BLUR', 'settings', 0,255, nothing)
cv2.createTrackbar('CONST_TRESH', 'settings', 0,255, nothing)
cv2.createTrackbar('TRESH_MIN', 'settings', 127,255, nothing)

while(True):
    captur
    _, frame = cap.read()
    #frame = frame[:,::-1,:]
    cv2.imshow('frame', frame)
    #frame = cv2.flip(frame, 2)
    frame = cv2.GaussianBlur(frame, (AREA_BLUR,AREA_BLUR), 0)
    
    ret, TRASH_FRAME = cv2.threshold (frame[:,:,1],TRESH_MIN,255,cv2.THRESH_BINARY)
    
    ADAPTIVE_TRASH_FRAME =cv2.adaptiveThreshold\
                           (frame[:,:,1],255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
                            cv2.THRESH_BINARY,AREA_TRESH,CONST_TRESH)

    cv2.imshow('frame', frame)
    cv2.imshow('frame_GREEN', frame[:,:,1])
    cv2.imshow('TRASH_FRAME', TRASH_FRAME)
    cv2.imshow('ADAPTIVE_TRASH_FRAME', ADAPTIVE_TRASH_FRAME)#ADAPTIVE_TRASH_FRAME

    if cv2.waitKey(1) & 0xFF == ord('q'):
            break
# When everything done, release the capture
cap.release()
cv2.destroyAllWindows() = cv2.imread('C:\\Users\\isnekrasov\\Downloads\\mlp.jpg')
    AREA_TRESH = (cv2.getTrackbarPos('AREA_TRESH','settings')//2)*2+3
    CONST_TRESH = cv2.getTrackbarPos('CONST_TRESH','settings')
    TRESH_MIN = cv2.getTrackbarPos('TRESH_MIN','settings')
    AREA_BLUR = (cv2.getTrackbarPos('AREA_BLUR','settings')//2)*2+1
    
    _, frame = cap.read()
    #frame = frame[:,::-1,:]
    cv2.imshow('frame', frame)
    #frame = cv2.flip(frame, 2)
    frame = cv2.GaussianBlur(frame, (AREA_BLUR,AREA_BLUR), 0)
    
    ret, TRASH_FRAME = cv2.threshold (frame[:,:,1],TRESH_MIN,255,cv2.THRESH_BINARY)
    
    ADAPTIVE_TRASH_FRAME =cv2.adaptiveThreshold\
                           (frame[:,:,1],255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
                            cv2.THRESH_BINARY,AREA_TRESH,CONST_TRESH)

    cv2.imshow('frame', frame)
    cv2.imshow('frame_GREEN', frame[:,:,1])
    cv2.imshow('TRASH_FRAME', TRASH_FRAME)
    cv2.imshow('ADAPTIVE_TRASH_FRAME', ADAPTIVE_TRASH_FRAME)#ADAPTIVE_TRASH_FRAME

    if cv2.waitKey(1) & 0xFF == ord('q'):
            break
# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()

