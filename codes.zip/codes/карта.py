from controller import Robot
import numpy as np
 
# Создаем экземпляр робота
robot = Robot()

# Получаем таймер
timestep = int(robot.getBasicTimeStep())

# Получаем доступ к Lidar
lidar = robot.getLidar('lidar')
if lidar is None:
    print("Ошибка: Lidar не найден. Проверьте имя и конфигурацию.")
    exit(1)

lidar.enable(timestep)

# Настройки для отображения карты
map_size = 500  # Размер карты (пиксели)
map_scale = 0.1  # Масштаб (метры на пиксель)
map_data = np.zeros((map_size, map_size))

def update_map(lidar_data):
    for angle in range(len(lidar_data)):
        distance = lidar_data[angle]
        if distance > 0 and distance < float('inf'):  # Игнорируем нулевые и бесконечные значения
            x = int((distance * np.cos(np.radians(angle))) / map_scale) + map_size // 2
            y = int((distance * np.sin(np.radians(angle))) / map_scale) + map_size // 2
            
            if 0 <= x < map_size and 0 <= y < map_size:
                map_data[y, x] = 1  # Обозначаем точку на карте

# Основной цикл
while robot.step(timestep) != -1:
    lidar_data = lidar.getRangeImage()
    update_map(lidar_data)

    # Отображение карты
    plt.imshow(map_data, cmap='gray', origin='lower')
    plt.title('Map')
    plt.pause(0.01)

plt.show()
