from controller import Robot, GPS, Camera, Receiver, Emitter
import cv2
import numpy as np
import random
import struct
 
timeStep = 32
max_velocity = 6.28
robot = Robot()
def nothing():
    pass

#установка колес
wheel1 = robot.getDevice("wheel1 motor")
wheel2 = robot.getDevice("wheel2 motor") 
wheel1.setPosition(float("inf"))       
wheel2.setPosition(float("inf"))

#установка датчиков
s0 = robot.getDevice("disens0")
s1 = robot.getDevice("disens1")
s2 = robot.getDevice("disens2")
s3 = robot.getDevice("disens3")
s4 = robot.getDevice("disens4")
s5 = robot.getDevice("disens5")
s6 = robot.getDevice("disens6")
s7 = robot.getDevice("disens7")
scolor = robot.getDevice("colour_sensor")
cameraC = robot.getDevice("camC")
cameraR = robot.getDevice("camR")
cameraL = robot.getDevice("camL")
gps = robot.getDevice("gps")

#включение датчиков
s0.enable(timeStep)
s1.enable(timeStep)
s2.enable(timeStep)
s3.enable(timeStep)
s4.enable(timeStep)
s5.enable(timeStep)
s6.enable(timeStep)
s7.enable(timeStep)
scolor.enable(timeStep)
cameraC.enable(timeStep)
cameraR.enable(timeStep)
cameraL.enable(timeStep)
gps.enable(timeStep)

#receiver = robot.getDevice("receiver")
emitter = robot.getDevice("emitter")
#receiver.enable(timeStep)

#кодировка цветов
ublack = [110, 110, 110]
black = [41,41,41]
blue = [63,63,252]
purple = [145,63,226]
brown = [209,175,101]
silverMin = [246,246,246]
silverMax = [252,252,252]
green = [33,249,33]
red = [252,63,63]
recognizedColor = ''

#функция определения цвета
def colorRec():
    if(sensColor[0] <= black[0] and sensColor[1] <= black[1] and sensColor[2] <= black[2]):
        recognizedColor = 'black'
    elif(sensColor[0] == ublack[0] and sensColor[1] == ublack[1] and sensColor[2] == ublack[2]):
        recognizedColor = 'black'
    elif(sensColor[1] > 2*sensColor[0] and sensColor[1] > 2*sensColor[2]):
        recognizedColor = 'green'
    elif(sensColor[0] > 2*sensColor[1] and sensColor[0] > 2*sensColor[2]):
        recognizedColor = 'red'
    elif(sensColor[0] >= silverMin[0] and sensColor[1] >= silverMin[1] and sensColor[2] >= silverMin[2] and sensColor[0] <= silverMax[0] and sensColor[1] <= silverMax[1] and sensColor[2] <= silverMax[2]):
        recognizedColor = 'silver'
    elif(sensColor[0] > sensColor[1] and sensColor[1] > sensColor[2]):
        recognizedColor = 'brown'
    elif(sensColor[2] > 2*sensColor[1] and sensColor[2] > 2*sensColor[0]):
        recognizedColor = 'blue'
    elif(sensColor[2] > sensColor[0] and sensColor[0] > sensColor[1]):
        recognizedColor = 'purple'
    else:
        #print("None")
        recognizedColor = 'none'
    return recognizedColor

def detect(img):
    tolerance = 20
    txt = 'None'
    img = img
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    height, width, _ = img.shape
    background_color = [[19, 30, 32], [61, 127, 139]]
    FG_color = [195, 0, 72]
    OP_color = [205, 191, 20]
    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    left_column = img[:, 0, :]  # Первый столбец
    right_column = img[:, -1, :]  # Последний столбец
    is_left_background = np.all(np.all(np.abs(left_column - background_color[0]) <= tolerance, axis=1) |np.all(np.abs(left_column - background_color[1]) <= tolerance, axis=1))
    is_right_background = np.all(np.all(np.abs(right_column - background_color[0]) <= tolerance, axis=1) |np.all(np.abs(right_column - background_color[1]) <= tolerance, axis=1))
    blacks = np.sum(gray_image < 10)
    whites = np.sum(gray_image > 206)
    print("blacks:", blacks)
    print("whites:", whites)
    if is_left_background and is_right_background:
        for i in range(4):
            if i ==0:
                lower_bound = np.array(OP_color) - tolerance
                upper_bound = np.array(OP_color) + tolerance
                lower_bound = np.clip(lower_bound, 0, 255)
                upper_bound = np.clip(upper_bound, 0, 255)
                mask = np.all((img >= lower_bound) & (img <= upper_bound), axis=-1)
                print(i)
                if np.any(mask):
                    txt = 'O'
                    break
            elif i == 1:
                lower_bound = np.array(FG_color) - tolerance
                upper_bound = np.array(FG_color) + tolerance
                lower_bound = np.clip(lower_bound, 0, 255)
                upper_bound = np.clip(upper_bound, 0, 255)
                print(i)
                mask = np.all((img >= lower_bound) & (img <= upper_bound), axis=-1)
                if np.any(mask):
                    txt = 'F'
                    break
            elif i == 2:
                if whites > 20 and blacks < 9:
                    txt = 'P'
                    print(i)
                    break
            elif i == 3:
                if blacks > 10 and blacks > whites*2:
                    txt ='C'
                    print(111)
                    break
            print(i, i)
        else:
            txt = 'None'
    return txt

start = robot.getTime()
t1 = start
q = 0
b = 0
lst = []
lstt = []
lstLev = []
lstdet = []
RL = True
while robot.step(timeStep) != -1:
    imageRGBSensor = scolor.getImage()
    sensColor = [scolor.imageGetRed(imageRGBSensor, 1, 0, 0),scolor.imageGetGreen(imageRGBSensor, 1, 0, 0),scolor.imageGetBlue(imageRGBSensor, 1, 0, 0)]
    recognizedColor = colorRec()
    Vs0 = s0.getValue()//0.001/1000
    Vs1 = s1.getValue()//0.001/1000
    Vs2 = s2.getValue()//0.001/1000
    Vs3 = s3.getValue()//0.001/1000
    Vs4 = s4.getValue()//0.001/1000
    Vs5 = s5.getValue()//0.001/1000
    Vs6 = s6.getValue()//0.001/1000
    Vs7 = s7.getValue()//0.001/1000
    if Vs7 < 0.07 or recognizedColor == 'black' or recognizedColor == 'green':
        wheel1.setVelocity(6)              
        wheel2.setVelocity(6)
        break
    elif Vs3 < 0.09 or Vs4 < 0.09:
        wheel1.setVelocity(6)              
        wheel2.setVelocity(-6)
    else:
        wheel1.setVelocity(6)              
        wheel2.setVelocity(6)
while robot.step(timeStep) != -1:
    
    #t1 = int(robot.getTime())
    
    x = int(gps.getValues()[0]*100)
    y = int(gps.getValues()[1]*100)
    z = int(gps.getValues()[2]*100)
    #print('x:', x, 'y:', y, 'z:', z)
    lstgps = [x, y, z]

    imageRGBSensor = scolor.getImage()
    sensColor = [scolor.imageGetRed(imageRGBSensor, 1, 0, 0),scolor.imageGetGreen(imageRGBSensor, 1, 0, 0),scolor.imageGetBlue(imageRGBSensor, 1, 0, 0)]
    #print(sensColor)
    recognizedColor = colorRec()
    #print('Цвет:', recognizedColor)

    Vs0 = s0.getValue()//0.001/1000
    Vs1 = s1.getValue()//0.001/1000
    Vs2 = s2.getValue()//0.001/1000
    Vs3 = s3.getValue()//0.001/1000
    Vs4 = s4.getValue()//0.001/1000
    Vs5 = s5.getValue()//0.001/1000
    Vs6 = s6.getValue()//0.001/1000
    Vs7 = s7.getValue()//0.001/1000
    #print('s0:', Vs0, 's1:', Vs1, 's2:', Vs2, 's3:', s3.getValue()//0.001/1000, 's4:', Vs4, 's5:', Vs5, 's6:', Vs6, 's7:', Vs7)

    if RL:
        if recognizedColor == 'black' or recognizedColor == 'green':
            speed1 = 3
            speed2 = -4
            wheel1.setVelocity(speed1)              
            wheel2.setVelocity(speed2)
            q = 10
            b = 2
        elif q != 0:
            wheel1.setVelocity(speed1)              
            wheel2.setVelocity(speed2)
            q -= 1
        elif b != 0:
            wheel1.setVelocity(6)              
            wheel2.setVelocity(6)
            b -= 1
        elif (Vs7 > 0.061 and Vs6 > 0.108):
            speed1 = 0
            speed2 = 6
            wheel1.setVelocity(speed1)              
            wheel2.setVelocity(speed2)
        elif (Vs3 < 0.09 or Vs4 < 0.09):
            speed1 = 6
            speed2 = -6
            wheel1.setVelocity(speed1)              
            wheel2.setVelocity(speed2)
            q = 1
        elif (Vs6 < 0.04 or Vs5 < 0.04 or Vs2 < 0.05):
            speed1 = 6
            speed2 = -6
            wheel1.setVelocity(speed1)              
            wheel2.setVelocity(speed2)
            q = 1
        elif (Vs7 < 0.059 and Vs6 < 0.09):
            speed1 = 6
            speed2 = -3
            wheel1.setVelocity(speed1)              
            wheel2.setVelocity(speed2)
        else:
            wheel1.setVelocity(6)              
            wheel2.setVelocity(6)

    imgL = cameraL.getImage()
    imgC = cameraC.getImage()
    imgR = cameraR.getImage()
    imgL = np.frombuffer(imgL, np.uint8).reshape((cameraL.getHeight(), cameraL.getWidth(), 4))
    imgC = np.frombuffer(imgC, np.uint8).reshape((cameraC.getHeight(), cameraC.getWidth(), 4))
    imgR = np.frombuffer(imgR, np.uint8).reshape((cameraR.getHeight(), cameraR.getWidth(), 4))
    
    frameL = cv2.cvtColor(imgL, cv2.COLOR_BGRA2BGR)
    #frameC = cv2.cvtColor(imgC, cv2.COLOR_BGRA2BGR)
    frameR = cv2.cvtColor(imgR, cv2.COLOR_BGRA2BGR)            

    if lstgps not in lstdet and Vs7 < 0.08:
        txtR = detect(frameR)
        if txtR != 'None':
            lstdet.extend(list([i, y, z] for i in range(x-3, x+4)))
            lstdet.extend(list([x, y, i] for i in range(z-3, z+4)))
            t = int(robot.getTime())
            while robot.step(timeStep) != -1:
                if int(robot.getTime()) > t+5:
                    print(txtR)
                    victimType = bytes(txtR, "utf-8")
                    message = struct.pack("i i c", x, z, victimType)
                    emitter.send(message)
                    break
                wheel1.setVelocity(0)              
                wheel2.setVelocity(0)
    
    
        
        

    lst1 = []
    lst.append([str(x), str(y), str(z)])
    if len(lst) > 250:
        del lst[0]
    for i in range(len(lst)):
        if lst[i] not in lst1:
            lst1.append(lst[i])
    if len(lst1) <= 23 and len(lst) == 250:
        if RL:
            speed1 = 6
            speed2 = -6
        else:
            speed2 = 6
            speed1 = -6
        wheel1.setVelocity(speed1)              
        wheel2.setVelocity(speed2)
        q = 10
        b = 10
        for i in range(23):
            lst.append([str(i)])
            if len(lst) > 250:
                del lst[0]
    #print(len(lst1))


