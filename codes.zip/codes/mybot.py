from controller import Robot
import numpy as np
import cv2

timeStep = 32
max_velocity = 6.28
startTime = 0
duration = 0

robot = Robot()

wheel1 = robot.getDevice("wheel1 motor")
wheel2 = robot.getDevice("wheel2 motor")

wheel1.setPosition(float("inf"))       
wheel2.setPosition(float("inf"))

s0 = robot.getDevice('ps0')
s1 = robot.getDevice('ps1')
s2 = robot.getDevice('ps2')
s3 = robot.getDevice('ps3')
s4 = robot.getDevice('ps4')
s5 = robot.getDevice('ps5')
s6 = robot.getDevice('ps6')
s7 = robot.getDevice('ps7')

s0.enable(timeStep)
s1.enable(timeStep)
s2.enable(timeStep)
s3.enable(timeStep)
s4.enable(timeStep)
s5.enable(timeStep)
s6.enable(timeStep)
s7.enable(timeStep)

colour_sensor = robot.getDevice("colour_sensor")
colour_sensor.enable(timeStep)

start = robot.getTime()
while robot.step(timeStep) != -1:
    #print(s5.getValue())
    
    speed1 = 1
    speed2 = 1
    
    if s7.getValue() < 0.1:
        speed2 = -1
    elif s6.getValue() < 0.1:
        speed2 = -1
    #if s5.getValue() > 0.15 and s7.getValue() < 0.1:
    #    speed1 = -1
    #elif s5.getValue() > 0.15 and s7.getValue() > 0.1:
    #    speed1 = -1
    
    if (robot.getTime() - startTime) < duration:
        pass
    else:
        startTime = 0
        duration = 0

        colour = colour_sensor.getImage()
        img = np.array(np.frombuffer(colour, np.uint8).reshape((colour_sensor.getHeight(), colour_sensor.getWidth(), 4)))
        img[:,:,2] = np.zeros([img.shape[0], img.shape[1]])
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)[0][0]
        print(str(hsv))
        
        if str(hsv) == '[ 30 255  54]':
            speed1 = 1
            speed2 = -1
        
    wheel1.setVelocity(speed1)              
    wheel2.setVelocity(speed2)    
    


    

    

    
